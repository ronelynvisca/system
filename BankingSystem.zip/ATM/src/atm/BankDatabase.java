/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atm;

/**
 *
 * @author ASUS
 */
public class BankDatabase {
    private Account account[];
    
    public BankDatabase()
    {
        account = new Account[3];
        account[0] = new Account(1234,"Jas",56789,1000.0,1200.0);
        account[1] = new Account(1010,"Lyn",56789,2000.0,100.0);
        account[2] = new Account(1122,"Ron",56789,2000.0,100.0);
    }
    
    private Account getAccount(int AccountNumber)
    {
        for(Account currentAccount : account)
        {
            if(currentAccount.getAccountNumber() == AccountNumber)
            {
                return currentAccount;
            }
         
        }
        return null;  
    }
    
    public double getAvailableBalance(int userAccountNumber)
    {
        return getAccount(userAccountNumber).getAvailableBalance();
    }
    
    public double getTotalBalance(int userAccountNumber)
    {
        return getAccount(userAccountNumber).getTotalBalance();
    }
    
    public String getName(int userAccountNumber)
    {
        return getAccount(userAccountNumber).getName();
    }

    void debit(int accountNumber, int amount) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    boolean authenticateUser(int accountNumber, int pin) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void credit(int accountNumber, double amount) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
   
    

