/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atm;

import java.util.jar.Attributes.Name;

/**
 *
 * @author ASUS
 */
public class Account {
    
    private int AccountNumber;
    private String AccountName; 
    private int pin;
    private double AvailableBalance;
    private double TotalBalance;
    
    public Account(int theAccountNumber, String theAccountName, int thePin, double theAvailableBalance, double theTotalBalance)
    {
        AccountNumber = theAccountNumber;
        AccountName = theAccountName;
        pin = thePin;
        AvailableBalance = theAvailableBalance;
        TotalBalance = theTotalBalance;
        
                
    }
    
    public double getAvailableBalance()
    {
        return AvailableBalance;
    }
    
    public double getTotalBalance()
    {
        return TotalBalance;
    }
    
    public int getAccountNumber()
    {
        return AccountNumber;
    }

    String getName() 
    {
        return AccountName;
    }
}
