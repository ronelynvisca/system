/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atm;

/**
 *
 * @author ASUS
 */
public class BalanceInquiry extends Transaction
{
    public BalanceInquiry(int userAccountNumber, Screen atmScreen, BankDatabase atmBankDatabase)
    {
        super( userAccountNumber, atmScreen, atmBankDatabase );
    }
    public void execute()
    {
        BankDatabase bankDatabase = getBankDatabase();
        Screen screen = getScreen();
        
        double availbaleBalance =
                bankDatabase.getAvailableBalance (getAccountNumber());
        double totalBalance =
                bankDatabase.getTotalBalance (getAccountNumber());
        
        screen.displayMessageLine("\nBalance Information:");
        screen.displayMessageLine("- Available balance");
        screen.displayMessageLine("availableBalance");
        screen.displayMessageLine("\n - Total balance:");
        screen.displayMessageLine("totalBalance");
        screen.displayMessageLine( "");
    }
        
}
